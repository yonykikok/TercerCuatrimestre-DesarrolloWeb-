$(function(){
    inicializarEventos();
})
function inicializarEventos(){
    $("#btnEnviarAjax").click(enviarAjax);
    $("#btnEnviarGet").click(enviarGet);
    $("#btnEnviarGetMensajes").click(enviarGetMensajes);
    $("#btnEnviarPost").click(enviarPost);
  //  $("#btnGetJSON").click(getJSON);
    $("#btnLoad").click(usarLoad);
}
function enviarAjax(e){
    e.preventDefault();
    var legajo = $("#txtLegajo").val();//obtiene el valor
    var nombre= $("#txtNombre").val();

    var parametros={
        "legajo":legajo,
        "nombre": nombre
    }
    $.ajax({
        url: "http://localhost:3000/concatenar",
        data: parametros,
        //type:post,
        //dataType:'json',
        beforeSend:function(){
            $("#info").html('<img src="./images/spin.gif" alt="preLoad">');
        },
        success:function(respuesta)
        {
            $("#info").html(respuesta);
        },
        error:function(xhr,status)
        {
            alert("ERROR "+ xhr.status+" "+xhr.statusText);
        },
        complete:function(xhr,status){
            alert("Peticion Terminada");
        }
    });
}
    function enviarGet(e){
        e.preventDefault();
        var legajo = $("#txtLegajo").val();//obtiene el valor
        var nombre= $("#txtNombre").val();

        var parametros={
            "legajo":legajo,
            "nombre": nombre
        }
        $.get("http://localhost:3000/concatenar",parametros,function(respuesta){
            $("#info").text(respuesta);
        });
    }
function enviarGetMensajes(e){
    e.preventDefault();
    e.preventDefault();
    var legajo = $("#txtLegajo").val();//obtiene el valor
    var nombre= $("#txtNombre").val();

    var parametros={
        "legajo":legajo,
        "nombre": nombre
    }
    $.get("http://localhost:3000/concatenar",parametros,function(respuesta){
        alert("correcto");
    }).done(function(){//concateanamos manejadores 
        alert("todo ok");
    }).fail(function(){
        alert("Fallo");
    }).always(function(){
        alert("siempre");
    });
}
function enviarPost(e){
    e.preventDefault();
    var legajo=$("#txtLegajo").val();
    var nombre=$("#txtNombre").val();
    var parametros={
        "legajo":legajo,
        "nombre":nombre
    };
    $.post("http://localhost:3000/loadpost",function(respuesta){
        console.log(respuesta);
    })
    
    $.post("http://localhost:3000/saludo",parametros,function(respuesta){
        console.log(respuesta);
    })
}

    function usarLoad(e){
        e.preventDefault();
        //$("#info").load("http://localhost:3000/loadhtml p");
        //$("#info").load("http://localhost:3000/loadhtml li");
        $("#info").load("http://localhost:3000/loadhtml div p");
    }
    