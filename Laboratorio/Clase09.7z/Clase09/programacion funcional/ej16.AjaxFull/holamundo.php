<?php

sleep(3);
echo "Hola mundo";

?>