var vec=[3,4,2,6,7,5];
var suma=0;/*
for(var i=0;i<vec.length;i++)
{
    suma+=vec[i];
}*/
/*
vec.forEach(function(numero){
    suma+=numero;
})*/ 
//devuelve un unico valor. se usa para promedio entre otras cosas
/*suma=vec.reduce(function(valorAnterior,ValorActual,indice){
   // console.log(valorAnterior);//muestra hasta el 5 porque no es anterior de nadie
    //console.log(ValorActual);
    //console.log(valorAnterior+" "+ValorActual);
    return valorAnterior+ValorActual;
},0);//el segundo parametro "-1" vendria a ser el "objetoAnterior"

console.log(suma);*/
suma=vec.reduce(function(mayor,ValorActual,indice){
    // console.log(valorAnterior);//muestra hasta el 5 porque no es anterior de nadie
     //console.log(ValorActual);
     //console.log(valorAnterior+" "+ValorActual);
    if(mayor<ValorActual)
    {
        return ValorActual;
    }
    else{
        return mayor;
    }
 });//el segundo parametro "-1" vendria a ser el "objetoAnterior"
 
 console.log(suma);